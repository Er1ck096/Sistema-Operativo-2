package edu.ulatina.dockerizedAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerizedApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
